package com.example.crawling2;


import android.view.View;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

@GlideModule
public final class MyAppGlideApp extends AppGlideModule {

}
