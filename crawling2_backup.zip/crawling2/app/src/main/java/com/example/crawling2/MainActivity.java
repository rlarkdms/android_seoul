package com.example.crawling2;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {
        public static final int REQUEST_CODE = 1001;
        ListView listView;
        ArrayAdapter<String> mGameListAdapter;
        TextView textView;
        Toolbar tb;
        ActionBar ab;

        @Override
        protected void onCreate(Bundle savedInstanceState)
        {
            super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = (ListView) findViewById(R.id.main_listView);
        textView = (TextView) findViewById(R.id.main_textView);
        tb=(Toolbar)findViewById(R.id.app_toolbar);
       // ab=getSupportActionBar();
        setSupportActionBar(tb);



        String[] gameArray = {
                "축제와 행사",
                "명소",
                "미술관&박물관",
                "공연"

       };
        List<String> gameList = new ArrayList<String>(Arrays.asList(gameArray));
        mGameListAdapter = new ArrayAdapter<String>(
                this,
                R.layout.activity_main,
                R.id.main_textView,
                gameList
        );
        listView.setAdapter(mGameListAdapter);
            System.out.println("확인 확인222");
        listView.setOnItemClickListener(itemClickListener);

    }
    private AdapterView.OnItemClickListener itemClickListener = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            String selectedGame = (String)parent.getAdapter().getItem(position);
            Intent intent = new Intent(getBaseContext(),SecondActivity.class);
            intent.putExtra("gameTitle", selectedGame);
            intent.putExtra("gameIndex", position);
            System.out.println("확인 확인");

            startActivity(intent);
        }
     };
//    public static void setListViewHeightBasedOnChildren(ListView listView) {
//        ListAdapter listAdapter = listView.getAdapter();
//        if (listAdapter == null) {
//            // pre-condition
//            return;
//        }
//
//        int totalHeight = 0;
//
//        int desiredWidth = View.MeasureSpec.makeMeasureSpec(listView.getWidth(), View.MeasureSpec.AT_MOST);
//        for (int i = 0; i < listAdapter.getCount(); i++) {
//            View listItem = listAdapter.getView(i, null, listView);
//            //listItem.measure(0, 0);
//            listItem.measure(desiredWidth, View.MeasureSpec.UNSPECIFIED);
//            totalHeight += listItem.getMeasuredHeight();
//        }
//        ViewGroup.LayoutParams params = listView.getLayoutParams();
//
//        params.height = totalHeight;
//        listView.setLayoutParams(params);
//
//        listView.requestLayout();
//    }



    }
